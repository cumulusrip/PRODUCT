export const Roles = {
  ADMIN: "admin",
  SUPER_ADMIN: "superadmin",
  HR: "hr",
  TEAM: "team",
  BD: "billingmanager",
  PM: "projectmanager",
  TL:"tl"
};
