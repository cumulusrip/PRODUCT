import React, { useEffect, useState, useCallback } from "react";
import { Loader2, BarChart, Search, CheckCircle, XCircle, Clock } from "lucide-react";
import { useLeave } from "../../context/LeaveContext";
import { SectionHeader } from '../../components/SectionHeader';
import { IconApproveButton, IconRejectButton, IconEditButton } from "../../../components/AllButtons/AllButtons";
import Pagination from "../../../components/components/Pagination"; // Import the Pagination component


export const LeaveManagement = () => {
    // Destructure properties from your LeaveContext
    const { hrLeaveDetails, hrLeave, postStatuses, loading, error } = useLeave();

    // State for search input
    const [searchTerm, setSearchTerm] = useState("");

    // State for filtering by status: "All", "Pending", "Approved", "Rejected"
    const [filterStatus, setFilterStatus] = useState("All");

    // State to hold the data after applying search and status filters
    const [filteredData, setFilteredData] = useState([]);

    // State to manage edit mode for each leave request
    const [editMode, setEditMode] = useState({});

    // Pagination states
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 11; // Defined here for clarity, can be a prop or constant

    // Fetch leave details on component mount
    useEffect(() => {
        hrLeaveDetails();
    }, []);

    // Memoize the filter function to prevent unnecessary re-renders
    const applyFilters = useCallback(() => {
        let currentFilteredData = hrLeave;

        // Apply search term filter
        if (searchTerm) {
            currentFilteredData = currentFilteredData.filter(leave =>
                leave.user_name && leave.user_name.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        // Apply status filter
        if (filterStatus !== "All") {
            currentFilteredData = currentFilteredData.filter(leave =>
                leave.status === filterStatus
            );
        }

        setFilteredData(currentFilteredData);
        setCurrentPage(1); // Reset to first page whenever filters change
    }, [searchTerm, filterStatus, hrLeave]); // Dependencies for useCallback

    // Run filter function whenever searchTerm, filterStatus, or hrLeave changes
    useEffect(() => {
        applyFilters();
    }, [applyFilters]);


    const handleStatusChange = async (id, newStatus) => {
        // Ensure that only the relevant status update is sent
        const updatedStatus = [{ id, status: newStatus }];
        await postStatuses(updatedStatus); // Call context function to update status
        setEditMode((prev) => ({ ...prev, [id]: false })); // Exit edit mode for this specific row
    };

    const toggleEditMode = (id) => {
        setEditMode((prev) => ({ ...prev, [id]: !prev[id] }));
    };

    // Calculate total pages based on filtered data
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);

    // Apply pagination to filtered data
    const paginatedLeaveRequests = filteredData.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    };

    return (
        <div className="rounded-2xl border border-gray-200 bg-white shadow-lg max-h-screen overflow-y-auto">
            <SectionHeader icon={BarChart} title="Leave Management" subtitle="View and manage employee leave requests" />

            {/* Search and Filter Section */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 sticky top-0 bg-white z-10 shadow-md">
                {/* Search Input */}
                <div className="flex items-center w-full max-w-md border border-gray-300 px-2 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                    <Search className="h-5 w-5 text-gray-400 mr-[5px]" />
                    <input
                        type="text"
                        className="w-full rounded-lg focus:outline-none py-2"
                        placeholder="Search by Employee Name..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>

                {/* Filter Buttons */}
                <div className="flex gap-2">
                    <button
                        className={`p-2 border rounded-lg ${
                            filterStatus === "All" ? "import-btn" : "import-btn"
                        }`}
                        onClick={() => setFilterStatus("All")}
                    >
                        All
                    </button>
                    <button
                        className={`p-2 border rounded-lg ${
                            filterStatus === "Pending" ? "weekly-btn" : "weekly-btn"
                        }`}
                        onClick={() => setFilterStatus("Pending")}
                    >
                        Pending
                    </button>
                    <button
                        className={`p-2 border rounded-lg ${
                            filterStatus === "Approved" ? "export-btn" : "export-btn"
                        }`}
                        onClick={() => setFilterStatus("Approved")}
                    >
                        Approved
                    </button>
                    <button
                        className={`p-2 border rounded-lg ${
                            filterStatus === "Rejected" ? "custom-btn" : "custom-btn"
                        }`}
                        onClick={() => setFilterStatus("Rejected")}
                    >
                        Rejected
                    </button>
                </div>
            </div>

            {/* Table Section */}
            <div className="max-w-full overflow-x-auto">
                <div className="min-w-[800px]">
                    <table className="w-full border-collapse">
                        <thead>
                            <tr className="table-th-tr-row table-bg-heading">
                                {["Date", "Employee Name", "Leave Type", "Duration", "Reason", "Status"].map((label, index) => (
                                    <th key={index} className="px-4 py-2 text-center font-semibold">{label}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {loading ? (
                                <tr>
                                    <td colSpan="6" className="px-6 py-8 text-center">
                                        <div className="flex items-center justify-center">
                                            <Loader2 className="h-6 w-6 animate-spin text-blue-500 mr-2" />
                                            <span className="text-gray-500">Loading leave requests...</span>
                                        </div>
                                    </td>
                                </tr>
                            ) : error ? ( // Display error message from context
                                <tr>
                                    <td colSpan="6" className="px-6 py-8 text-center text-red-500">
                                        Error: {error}
                                    </td>
                                </tr>
                            ) : paginatedLeaveRequests.length === 0 ? ( // Use paginatedLeaveRequests here
                                <tr>
                                    <td colSpan="6" className="px-6 py-8 text-center">
                                        <div className="flex flex-col items-center justify-center">
                                            <div className="rounded-full bg-gray-100 p-3">
                                                <svg className="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                            </div>
                                            <h3 className="mt-2 text-sm font-medium text-gray-900">No leave requests found</h3>
                                            <p className="mt-1 text-sm text-gray-500">
                                                {searchTerm || filterStatus !== "All"
                                                    ? "No matching leave requests found for your search/filter."
                                                    : "No leave requests have been submitted yet."}
                                            </p>
                                        </div>
                                    </td>
                                </tr>
                            ) : (
                                paginatedLeaveRequests.map((leave) => ( // Use paginatedLeaveRequests here
                                    <tr key={leave.id} className="hover:bg-blue-50/50 transition-all duration-200 ease-in-out">
                                        <td className="px-6 py-4 text-center text-gray-700">{formatDate(leave.start_date)}</td>
                                        <td className="px-6 py-4 text-center text-gray-700">{leave.user_name}</td>
                                        <td className="px-6 py-4 text-center text-gray-700">{leave.leave_type}</td>
                                        <td className="px-6 py-4 text-center text-gray-700">{leave.hours ? `${leave.hours} Hours` : "Full Day"}</td>
                                        <td className="px-6 py-4 text-center text-gray-700">{leave.reason}</td>
                                        <td className="px-6 py-4 flex items-center justify-center text-center">
                                            {editMode[leave.id] ? (
                                                <div className="flex items-center gap-4">
                                                    <div className="relative group">
                                                        <IconApproveButton onClick={() => handleStatusChange(leave.id, "Approved")} />
                                                        <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2
                                                            whitespace-nowrap bg-white text-black text-sm px-2 py-1 rounded
                                                            opacity-0 group-hover:opacity-100 transition pointer-events-none shadow">
                                                                Approve
                                                        </span>
                                                    </div>

                                                    <div className="relative group">
                                                        <IconRejectButton onClick={() => handleStatusChange(leave.id, "Rejected")} />
                                                        <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2
                                                            whitespace-nowrap bg-white text-black text-sm px-2 py-1 rounded
                                                            opacity-0 group-hover:opacity-100 transition pointer-events-none shadow">
                                                                Reject
                                                        </span>
                                                    </div>
                                                </div>
                                            ) : (
                                                <div className="flex items-center gap-3">
                                                    {/* Display status icon based on the current status */}
                                                    {leave.status === "Approved" && <CheckCircle className="text-green-500 h-7 w-7" />}
                                                    {leave.status === "Rejected" && <XCircle className="text-red-500 h-7 w-7" />}
                                                    {leave.status === "Pending" && <Clock className="text-yellow-500 h-7 w-7" />}

                                                    {/* Edit button to toggle edit mode */}

                                                    <div className="relative group">
                                                        <IconEditButton onClick={() => toggleEditMode(leave.id)} />
                                                        <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2
                                                            whitespace-nowrap bg-white text-black text-sm px-2 py-1 rounded
                                                            opacity-0 group-hover:opacity-100 transition pointer-events-none shadow">
                                                                Edit
                                                        </span>
                                                    </div>
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>

                    {/* Pagination */}
                    <div className="p-4">
                        <Pagination
                            currentPage={currentPage}
                            totalPages={totalPages}
                            onPageChange={setCurrentPage}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};